package com.example.spring_boot_api_advanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AuthServiceTests {

    @Test
    void contextLoads() {
        // Adicione os testes para a lógica de autenticação aqui
    }
}
package com.example.spring_boot_api_advanced; // Ajuste o pacote conforme necessário

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApiApplicationTests {

    @Test
    void contextLoads() {
        // Este teste verifica se o contexto da aplicação carrega corretamente
    }
}
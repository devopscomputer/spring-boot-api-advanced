package com.example.spring_boot_api_advanced.dto; // Correto

public class AuthRequestDto {
    private String username;
    private String password;

    // Getters e Setters
}
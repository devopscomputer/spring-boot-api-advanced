package com.example.spring_boot_api_advanced.dto; // Correto

public class UserDto {
    private Long id;
    private String username;

    // Getters e Setters
}
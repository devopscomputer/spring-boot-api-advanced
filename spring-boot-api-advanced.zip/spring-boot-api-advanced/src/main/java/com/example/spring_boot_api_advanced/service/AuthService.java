package com.example.spring_boot_api_advanced.service; // Correto

import org.springframework.stereotype.Service;

@Service
public class AuthService {
    // Lógica de autenticação
}
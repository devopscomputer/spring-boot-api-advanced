package com.example.spring_boot_api_advanced.repository; // Correto

import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService {
    // Implementação para detalhes do usuário
}